#pragma once
#include <vector>
#include <glm/glm.hpp>
#include "MeshModel.h"

class Light
{
private:
	int type;
	glm::vec4 intensity;
	glm::vec4 position;
	glm::vec3 direction;
public:
	Light(int type, std::string name);
	~Light();
	glm::vec4 getDirection() const;
	glm::vec4 getPosition() const;
	const glm::vec4& getIntensity() const;
	int getType() const;
	std::string getName();
	void setDirection(glm::vec3 direction);
	void setPosition(float* pos);
	void setType(int type);
	void setIntensity(const glm::vec4& i);

};

