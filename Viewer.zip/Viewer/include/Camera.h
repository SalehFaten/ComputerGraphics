#pragma once
#include <memory>
#include <glm/glm.hpp>
#include "MeshModel.h"
#include "Utils.h"


class Camera : public MeshModel {
private:
	float znear;
	float zfar;
	float aspect;
	float prm;
	int activeView;

	glm::mat4x4 view_transformation_;
	glm::mat4x4 projection_transformation_;
	glm::mat4x4 worldViewTransformation;
	glm::mat4 mat_inv;



public:
	Camera(const glm::vec3& eye, const glm::vec3& at, const glm::vec3& up, const MeshModel& cameraModel);
	~Camera();
	float getZNear() const;
	float getZFar() const;
	float getParam() const;
	float getAspect() const;
	glm::mat4x4 getViewTransformation();
	glm::mat4x4 getWorldViewTransformation();
	glm::mat4x4 GetProjectionTransformation();
	void SetCameraLookAt(const glm::vec3& eye, const glm::vec3& at, const glm::vec3& up);
	void SetOrthographicProjection(
		const float height,
		const float aspectRatio,
		const float near,
		const float far);
	void SetPerspectiveProjection(
		const float fovy,
		const float aspect,
		const float near,
		const float far);
	void SetZoom(const float zoom);
	void SetAspectRatio(const float ratio);
	bool isPerspective() const;
	void setObjectTransform(const glm::mat4& mat);
	void setWorldTransform(const glm::mat4& mat);
};
