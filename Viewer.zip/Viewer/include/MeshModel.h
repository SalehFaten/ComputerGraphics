#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <string>
#include <memory>
#include "Face.h"
#include "ShaderProgram.h"
#include "Texture2D.h"

struct Vertex {
	glm::vec3 position;
	glm::vec3 normal;
	glm::vec2 tex;
};
class MeshModel
{
protected:

	std::string model_name_;
	std::vector<Vertex> boxVertices;
	std::vector<Vertex> modelVertices;
	glm::mat4x4 worldTransform;
	glm::mat4x4 localTransform;

	GLuint vao;
	GLuint vbo;
	GLuint boundingVAO;
	GLuint boundingVBO;
	Texture2D texture;

	glm::vec4 colorAmbient;
	glm::vec4 colorDiffuse;
	glm::vec4 colorSpecular;
	glm::vec4 colorLine;

	glm::mat4x4 worldScaleTransform;
	glm::mat4x4 worldTranslationTransform;
	glm::mat4x4 worldxRotationTransform;
	glm::mat4x4 worldyRotationTransform;
	glm::mat4x4 worldzRotationTransform;
	glm::mat4x4 scaleTransform;
	glm::mat4x4 translationTransform;
	glm::mat4x4 xRotationTransform;
	glm::mat4x4 yRotationTransform;
	glm::mat4x4 zRotationTransform;


	bool drawBounding;
	bool useTexture;
	bool wireFrame;

	float K_Ambient;
	float K_Diffuse;
	float K_Specular;
	float Exp_Specular;

public:
	MeshModel(const std::vector<Face>& faces, const std::vector<glm::vec3>& vertices, const std::vector<glm::vec3>& normals, const std::vector<glm::vec2>& textureCoords, const std::string& modelName = "");
	MeshModel(const MeshModel& ref, const std::string& name = "");
	virtual ~MeshModel();

	//const Face& GetFace(int index) const;
	//int GetFacesCount() const;
	const std::string& GetModelName();
	//const std::string& GetModelName() const;
	void drawModel(ShaderProgram& shader) const;
	void DrawWireFrame();
	void setBounding();
	const glm::vec3 getPosition() const;

	void xLocalRotate(const float angle, bool n = false);
	void yLocalRotate(const float angle, bool n = false);
	void zLocalRotate(const float angle, bool n = false);
	void xRotateWorld(const float angle, bool n = false);
	void yRotateWorld(const float angle, bool n = false);
	void zRotateWorld(const float angle, bool n = false);
	void LocalTranslate(const float* translation, bool n = false);
	void WorldTranslate(const float* translation, bool n = false);
	void LocalScale(const float* scale, bool n = false);
	void WorldScale(const float* scale, bool n = false);
	virtual void setLocalTransformation(const glm::mat4& mat);
	virtual void setWorldTransformation(const glm::mat4& mat);

	void SetAmbientColor(const glm::vec4& color);
	void SetDiffuseColor(const glm::vec4& color);
	void SetSpecularColor(const glm::vec4& color);
	void SetLineColor(const glm::vec4& color);
	void setKAmbient(float k);
	void setKDiffuse(float k);
	void setKSpecular(float k);
	void setSpecularExp(float k);
	void LoadTextures(const char * path);
	void MapTexture();
	void setPlanarMap();
	void setCylindricalMap();
	void setSphericalMap();


};
