#include "Face.h"

Face::Face(std::istream& issLine)
{
	vertex_indices_ = { 0, 0, 0 };
	normal_indices_ = { 0, 0, 0 };
	texture_indices_ = { 0, 0, 0 };

	char c;
	for (int i = 0; i < 3; i++)
	{
		issLine >> std::ws >> vertex_indices_.at(i) >> std::ws;

		if (issLine.peek() != '/')
		{
			continue;
		}

		issLine >> c >> std::ws;

		if (issLine.peek() == '/')
		{
			issLine >> c >> std::ws >> normal_indices_.at(i);
			continue;
		}
		else
		{
			issLine >> texture_indices_.at(i);
		}

		if (issLine.peek() != '/')
		{
			continue;
		}

		issLine >> c >> normal_indices_.at(i);
	}
}

Face::Face(int v1, int v2, int v3, int t1, int t2, int t3, int n1, int n2, int n3)
{
	vertex_indices_ = { 0, 0, 0 };
	normal_indices_ = { 0, 0, 0 };
	texture_indices_ = { 0, 0, 0 };

	vertex_indices_[0] = v1;
	vertex_indices_[1] = v2;
	vertex_indices_[2] = v3;

	normal_indices_[0] = n1;
	normal_indices_[1] = n2;
	normal_indices_[2] = n3;

	texture_indices_[0] = t1;
	texture_indices_[1] = t2;
	texture_indices_[2] = t3;
}

Face::Face(int v1, int v2, int v3)
{
	this->vertex_indices_ = { 0, 0, 0 };
	this->normal_indices_ = { 0, 0, 0 };
	this->texture_indices_ = { 0, 0, 0 };
	this->vertex_indices_[0] = v1 + 1;
	this->vertex_indices_[1] = v2 + 1;
	this->vertex_indices_[2] = v3 + 1;
}

Face::~Face()
{

}

const int Face::GetVertexIndex(int index)
{
	return vertex_indices_[index] - 1;
}

const int Face::GetNormalIndex(int index)
{
	return normal_indices_[index] - 1;
}

const int Face::GetTextureIndex(int index)
{
	return texture_indices_[index] - 1;
}
