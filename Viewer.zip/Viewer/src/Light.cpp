#include "Light.h"

Light::Light(int type, std::string name)
{
	this->type = type;
	this->direction = glm::vec4(1.0f, 0.0f, 0.0f, 1.0f);
	this->intensity = glm::vec4(1.0f);
	this->position = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
}

Light::~Light()
{
}

glm::vec4 Light::getDirection() const
{
	return glm::vec4(this->direction, 1.0f);
}

int Light::getType() const
{
	return this->type;
}

void Light::setType(int type)
{
	this->type = type;
}

std::string Light::getName()
{
	if (type) {
		return "Point";
	}
	return "Parallel";
}

void Light::setIntensity(const glm::vec4 & i)
{
	this->intensity = i;
}

const glm::vec4 & Light::getIntensity() const
{
	return this->intensity;
}

glm::vec4 Light::getPosition() const
{
	return this->position;
}

void Light::setDirection(glm::vec3 direction) {
	this->direction = direction;
}

void Light::setPosition(float * pos)
{
	this->position.x = pos[0];
	this->position.y = pos[1];
	this->position.z = pos[2];
}

