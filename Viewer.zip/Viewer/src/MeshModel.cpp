#include "MeshModel.h"
#include "Utils.h"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>

constexpr auto PI = 3.14159265359f;

MeshModel::MeshModel(const std::vector<Face>& faces, const std::vector<glm::vec3>& vertices, const std::vector<glm::vec3>& normals, const std::vector<glm::vec2>& textureCoords, const std::string& modelName) :
	model_name_(modelName),
	worldTransform(glm::mat4x4(1.0f)),
	localTransform(glm::mat4x4(1.0f)),
	worldScaleTransform(glm::mat4x4(1.0f)),
	worldTranslationTransform(glm::mat4x4(1.0f)),
	worldxRotationTransform(glm::mat4x4(1.0f)),
	worldyRotationTransform(glm::mat4x4(1.0f)),
	worldzRotationTransform(glm::mat4x4(1.0f)),
	scaleTransform(glm::mat4x4(1.0f)),
	translationTransform(glm::mat4x4(1.0f)),
	xRotationTransform(glm::mat4x4(1.0f)),
	yRotationTransform(glm::mat4x4(1.0f)),
	zRotationTransform(glm::mat4x4(1.0f))
{
	this->drawBounding = false;
	this->wireFrame = false;
	this->useTexture = false;
	this->K_Ambient = 1.0f;
	this->K_Diffuse = 1.0f;
	this->K_Specular = 1.0f;
	this->Exp_Specular = 50.0f;

	glm::vec3 min((float)std::numeric_limits<int>::max());
	glm::vec3 max((float)std::numeric_limits<int>::min());

	for (auto ver : vertices) {
		if (ver.x < min.x)
			min.x = ver.x;
		if (ver.x > max.x)
			max.x = ver.x;
		if (ver.y < min.y)
			min.y = ver.y;
		if (ver.y > max.y)
			max.y = ver.y;
		if (ver.z < min.z)
			min.z = ver.z;
		if (ver.z > max.z)
			max.z = ver.z;
	}
	Vertex v0, v1, v2, v3, v4, v5, v6, v7;
	v0.normal = v0.position = glm::vec3(min.x, min.y, min.z); // left low close 0
	v1.normal = v1.position = glm::vec3(max.x, min.y, min.z); // right low close 1
	v2.normal = v2.position = glm::vec3(min.x, max.y, min.z); // left high close 2
	v3.normal = v3.position = glm::vec3(max.x, max.y, min.z); // right high close 3
	v4.normal = v4.position = glm::vec3(min.x, min.y, max.z); // left low far 4
	v5.normal = v5.position = glm::vec3(max.x, min.y, max.z); // right low far 5
	v6.normal = v6.position = glm::vec3(min.x, max.y, max.z); // left high far 6
	v7.normal = v7.position = glm::vec3(max.x, max.y, max.z); // right high far 7
	v0.tex = v1.tex = v2.tex = v3.tex = v4.tex = v5.tex = v6.tex = v7.tex = glm::vec2(0.0f, 0.0f);
	boxVertices.reserve(36);
	boxVertices.push_back(v0); boxVertices.push_back(v1); boxVertices.push_back(v3);
	boxVertices.push_back(v0); boxVertices.push_back(v1); boxVertices.push_back(v2);
	boxVertices.push_back(v1); boxVertices.push_back(v3); boxVertices.push_back(v5);
	boxVertices.push_back(v1); boxVertices.push_back(v5); boxVertices.push_back(v7);
	boxVertices.push_back(v4); boxVertices.push_back(v5); boxVertices.push_back(v6);
	boxVertices.push_back(v5); boxVertices.push_back(v6); boxVertices.push_back(v7);
	boxVertices.push_back(v0); boxVertices.push_back(v2); boxVertices.push_back(v4);
	boxVertices.push_back(v2); boxVertices.push_back(v4); boxVertices.push_back(v6);
	boxVertices.push_back(v2); boxVertices.push_back(v3); boxVertices.push_back(v7);
	boxVertices.push_back(v2); boxVertices.push_back(v6); boxVertices.push_back(v7);
	boxVertices.push_back(v0); boxVertices.push_back(v1); boxVertices.push_back(v5);
	boxVertices.push_back(v0); boxVertices.push_back(v4); boxVertices.push_back(v5);

	modelVertices.reserve(3 * faces.size());
	for (auto face : faces) {
		for (int i = 0; i < 3; ++i) {
			Vertex vertex;
			vertex.position = vertices[face.GetVertexIndex(i)];
			vertex.normal = normals[face.GetVertexIndex(i)];
			if ((textureCoords.size() > 0)) {
				vertex.tex = textureCoords[face.GetTextureIndex(i)];
			}
			else {
				vertex.tex = glm::vec2(vertex.position.x, vertex.position.z);
			}
			modelVertices.push_back(vertex);
		}
	}
	//GL stuff
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, modelVertices.size() * sizeof(Vertex), &modelVertices[0], GL_STATIC_DRAW);

	// load vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));

	// load normals
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));

	// load textures
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, tex));

	// unbind
	glBindVertexArray(0);

	//bounding box gen
	glGenVertexArrays(1, &boundingVAO);
	glBindVertexArray(boundingVAO);

	glGenBuffers(1, &boundingVBO);
	glBindBuffer(GL_ARRAY_BUFFER, boundingVBO);
	glBufferData(GL_ARRAY_BUFFER, boxVertices.size() * sizeof(Vertex), &boxVertices[0], GL_STATIC_DRAW);

	// load vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));

	// load normals
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));

	// load textures
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, tex));

	// unbind
	glBindVertexArray(0);
}

MeshModel::MeshModel(const MeshModel & ref, const std::string & name)
{
	this->drawBounding = false;
	this->K_Ambient = 1.0f;
	this->K_Diffuse = 1.0f;
	this->K_Specular = 1.0f;
	this->Exp_Specular = 1.0f;
	this->useTexture = ref.useTexture;
	this->wireFrame = ref.wireFrame;
	this->boxVertices = ref.boxVertices;
	this->modelVertices = ref.modelVertices;
	this->model_name_ = ref.model_name_;
	this->localTransform = ref.localTransform;
	this->worldTransform = ref.worldTransform;

	this->worldScaleTransform = ref.worldScaleTransform;
	this->worldTranslationTransform = ref.worldTranslationTransform;
	this->worldxRotationTransform = ref.worldxRotationTransform;
	this->worldyRotationTransform = ref.worldyRotationTransform;
	this->worldzRotationTransform = ref.worldzRotationTransform;

	this->scaleTransform = ref.worldTransform;
	this->translationTransform = ref.translationTransform;
	this->xRotationTransform = ref.xRotationTransform;
	this->yRotationTransform = ref.yRotationTransform;
	this->zRotationTransform = ref.zRotationTransform;

	//GL stuff
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, modelVertices.size() * sizeof(Vertex), &modelVertices[0], GL_STATIC_DRAW);

	// load vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));

	// load normals
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));

	// load textures
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, tex));

	// unbind
	glBindVertexArray(0);

	//bounding box gen
	glGenVertexArrays(1, &boundingVAO);
	glBindVertexArray(boundingVAO);

	glGenBuffers(1, &boundingVBO);
	glBindBuffer(GL_ARRAY_BUFFER, boundingVBO);
	glBufferData(GL_ARRAY_BUFFER, boxVertices.size() * sizeof(Vertex), &boxVertices[0], GL_STATIC_DRAW);

	// load vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));

	// load normals
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));

	// load textures
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, tex));

	// unbind
	glBindVertexArray(0);
}

MeshModel::~MeshModel()
{
	glDeleteVertexArrays(1, &vao);
	glDeleteBuffers(1, &vbo);
}

void MeshModel::drawModel(ShaderProgram& shader) const
{
	shader.setUniform("model", worldTransform * localTransform);
	shader.setUniform("material.AmbientColor", colorAmbient);
	shader.setUniform("material.DiffuseColor", colorDiffuse);
	shader.setUniform("material.SpecualrColor", colorSpecular);
	shader.setUniform("material.KA", K_Ambient);
	shader.setUniform("material.KD", K_Diffuse);
	shader.setUniform("material.KS", K_Specular);
	shader.setUniform("material.KSE", 100 / Exp_Specular);
	shader.setUniform("hasTex", this->useTexture);

	if (!wireFrame) {
		texture.bind(0);
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glBindVertexArray(vao);
		glDrawArrays(GL_TRIANGLES, 0, (GLsizei)modelVertices.size());
		glBindVertexArray(0);
		texture.unbind(0);
	}

	shader.setUniform("material.AmbientColor", colorLine);
	shader.setUniform("material.DiffuseColor", colorLine);
	shader.setUniform("material.SpecualrColor", colorLine);

	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glBindVertexArray(vao);
	glDrawArrays(GL_TRIANGLES, 0, (GLsizei)modelVertices.size());
	glBindVertexArray(0);

	if (drawBounding) {
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glBindVertexArray(boundingVAO);
		glDrawArrays(GL_TRIANGLES, 0, (GLsizei)boxVertices.size());
		glBindVertexArray(0);
	}
}

void MeshModel::LoadTextures(const char * path)
{
	texture.loadTexture(path, true);
}

/*void MeshModel::LoadBombTexture()
{
	texture.genRandomTexture();
}*/

void MeshModel::MapTexture()
{
	this->useTexture = !useTexture;
}

void MeshModel::setPlanarMap()
{
	for (Vertex& ver : modelVertices) {
		ver.tex = glm::vec2(ver.position.x, ver.position.z);
	}

	glBindVertexArray(vao);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferSubData(GL_ARRAY_BUFFER, 0, modelVertices.size() * sizeof(Vertex), &modelVertices[0]);

	glBindVertexArray(0);
}

void MeshModel::setCylindricalMap()
{
	for (Vertex& ver : modelVertices) {
		float theta = glm::atan(ver.position.z / ver.position.x);
		ver.tex = glm::normalize(glm::abs(glm::vec2(glm::cos(theta), glm::sin(theta))));
	}

	glBindVertexArray(vao);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferSubData(GL_ARRAY_BUFFER, 0, modelVertices.size() * sizeof(Vertex), &modelVertices[0]);

	glBindVertexArray(0);
}

void MeshModel::setSphericalMap()
{
	for (Vertex& ver : modelVertices) {
		ver.tex = glm::normalize(glm::vec2(glm::atan(ver.position.x, ver.position.y) / 2 * PI + 0.5f, 0.5f - glm::asin(ver.position.z) / PI));
	}

	glBindVertexArray(vao);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferSubData(GL_ARRAY_BUFFER, 0, modelVertices.size() * sizeof(Vertex), &modelVertices[0]);

	glBindVertexArray(0);
}

void MeshModel::xLocalRotate(const float angle, bool n)
{
	const glm::mat4 mat = Utils::getRotationMatrix(angle, 'x');;
	if (n) {
		xRotationTransform = mat * xRotationTransform;
	}
	else {
		xRotationTransform = mat;
	}
	setLocalTransformation(mat);
}

void MeshModel::yLocalRotate(const float angle, bool n)
{
	const glm::mat4 mat = Utils::getRotationMatrix(angle, 'y');
	if (n) {
		yRotationTransform = mat * yRotationTransform;
	}
	else {
		yRotationTransform = mat;
	}
	setLocalTransformation(mat);
}

void MeshModel::zLocalRotate(const float angle, bool n)
{
	const glm::mat4 mat = Utils::getRotationMatrix(angle, 'z');
	if (n) {
		zRotationTransform = mat * zRotationTransform;
	}
	else {
		zRotationTransform = mat;
	}
	setLocalTransformation(mat);
}

void MeshModel::LocalTranslate(const float * translation, bool n)
{
	const glm::mat4 mat = Utils::getTranslationMatrix(glm::vec3(translation[0], translation[1], translation[2]));
	if (n) {
		translationTransform = mat * translationTransform;
	}
	else {
		translationTransform = mat;
	}
	setLocalTransformation(mat);
}

void MeshModel::LocalScale(const float * scale, bool n)
{
	const glm::mat4 mat = Utils::getScaleMatrix(glm::vec3(scale[0], scale[1], scale[2]));
	if (n) {
		scaleTransform = mat * scaleTransform;
	}
	else {
		scaleTransform = mat;
	}
	setLocalTransformation(mat);
}

void MeshModel::xRotateWorld(const float angle, bool n)
{
	const glm::mat4 mat = Utils::getRotationMatrix(angle, 'x');
	if (n) {
		worldxRotationTransform = mat * worldxRotationTransform;
	}
	else {
		worldxRotationTransform = mat;
	}
	setWorldTransformation(mat);
}

void MeshModel::yRotateWorld(const float angle, bool n)
{
	const glm::mat4 mat = Utils::getRotationMatrix(angle, 'y');
	if (n) {
		worldyRotationTransform = mat * worldyRotationTransform;
	}
	else {
		worldyRotationTransform = mat;
	}
	setWorldTransformation(mat);
}

void MeshModel::zRotateWorld(const float angle, bool n)
{
	const glm::mat4 mat = Utils::getRotationMatrix(angle, 'z');
	if (n) {
		worldzRotationTransform = mat * worldzRotationTransform;
	}
	else {
		worldzRotationTransform = mat;
	}
	setWorldTransformation(mat);
}

void MeshModel::WorldTranslate(const float * translation, bool n)
{
	const glm::mat4 mat = Utils::getTranslationMatrix(glm::vec3(translation[0], translation[1], translation[2]));
	if (n) {
		worldTranslationTransform = mat * worldTranslationTransform;
	}
	else {
		worldTranslationTransform = mat;
	}
	setWorldTransformation(mat);
}

void MeshModel::WorldScale(const float * scale, bool n)
{
	const glm::mat4 mat = Utils::getScaleMatrix(glm::vec3(scale[0], scale[1], scale[2]));
	if (n) {
		worldScaleTransform = mat * worldScaleTransform;
	}
	else {
		worldScaleTransform = mat;
	}
	setWorldTransformation(mat);
}

const glm::vec3 MeshModel::getPosition() const
{
	glm::vec4 temp(0.0f, 0.0f, 0.0f, 1.0f);
	temp = worldTransform * localTransform * temp;
	glm::vec3 t(temp.x, temp.y, temp.z);
	return t / temp.w;
}

const std::string& MeshModel::GetModelName()
{
	return model_name_;
}

void MeshModel::SetAmbientColor(const glm::vec4 & color)
{
	this->colorAmbient = color;
}

void MeshModel::SetDiffuseColor(const glm::vec4 & color)
{
	this->colorDiffuse = color;
}

void MeshModel::SetSpecularColor(const glm::vec4 & color)
{
	this->colorSpecular = color;
}

void MeshModel::SetLineColor(const glm::vec4 & color)
{
	this->colorLine = color;
}

void MeshModel::setKAmbient(float k)
{
	this->K_Ambient = k;
}

void MeshModel::setKDiffuse(float k)
{
	this->K_Diffuse = k;
}

void MeshModel::setKSpecular(float k)
{
	this->K_Specular = k;
}

void MeshModel::setSpecularExp(float k)
{
	this->Exp_Specular = k;
}

void MeshModel::setBounding()
{
	this->drawBounding = !this->drawBounding;
}

void MeshModel::DrawWireFrame()
{
	this->wireFrame = !this->wireFrame;
}

void MeshModel::setLocalTransformation(const glm::mat4 & mat)
{
	localTransform = translationTransform * xRotationTransform * yRotationTransform * zRotationTransform * scaleTransform;
}

void MeshModel::setWorldTransformation(const glm::mat4 & mat)
{
	worldTransform = worldTranslationTransform * worldxRotationTransform * worldyRotationTransform * worldzRotationTransform * worldScaleTransform;
}
