#include <iostream>
#include "Scene.h"
#include "MeshModel.h"
#include "Light.h"
#include <string>

Scene::Scene() :
	active_camera_index_(-1),
	active_model_index_(-1),
	active_light_index_(-1),
	fogColor((0.5f, 0.5f, 0.5f, 1.0f)),
	ambientColor((0.8f, 0.8f, 0.8f, 1.0f))
{
	this->fogType = 0;
	this->shadingModel = 0;
	this->aliasLevel = 0;
}

void Scene::AddModel(const std::shared_ptr<MeshModel>& model)
{
	mesh_models_.push_back(model);
	active_model_index_ = (int)mesh_models_.size() - 1;
}

const int Scene::GetModelCount() const
{
	return (int)mesh_models_.size();
}

void Scene::AddCamera(const std::shared_ptr<Camera>& camera)
{
	cameras_.push_back(camera);
	active_camera_index_ = (int)cameras_.size() - 1;
}

const int Scene::GetCameraCount() const
{
	return (int)cameras_.size();
}

void Scene::AddLight(const std::shared_ptr<Light>& light)
{
	lights.push_back(light);
	active_light_index_ = (int)lights.size() - 1;
}

const int Scene::GetLightCount() const
{
	return (int)lights.size();
}

void Scene::SetActiveCameraIndex(int index)
{
	if (index >= 0 && index < cameras_.size())
	{
		active_camera_index_ = index;
	}
}

const int Scene::GetActiveCameraIndex() const
{
	return active_camera_index_;
}

void Scene::SetActiveModelIndex(int index)
{
	if (index >= 0 && index < mesh_models_.size())
	{
		active_model_index_ = index;
	}
}

const int Scene::GetActiveModelIndex() const
{
	return active_model_index_;
}

void Scene::SetActiveLightIndex(int index)
{
	if (index >= 0 && index < lights.size())
	{
		active_light_index_ = index;
	}
}

const int Scene::GetActiveLightIndex() const
{
	return active_light_index_;
}

const std::shared_ptr<MeshModel> Scene::GetModel(int index) const
{
	if (index >= 0 && index < mesh_models_.size()) {
		return this->mesh_models_[index];
	}
	return nullptr;
}

const std::shared_ptr<Camera> Scene::getCamera(int index) const
{
	if (index >= 0 && index < cameras_.size()) {
		return this->cameras_[index];
	}
	return nullptr;
}

const std::shared_ptr<Light> Scene::getLight(int index) const
{
	if (index >= 0 && index < lights.size()) {
		return this->lights[index];
	}
	return nullptr;
}

const std::shared_ptr<MeshModel> Scene::GetActiveModel() const
{
	return GetModel(active_model_index_);
}

const std::shared_ptr<Camera> Scene::getActiveCamera() const
{
	return getCamera(active_camera_index_);
}

const std::shared_ptr<Light> Scene::getActiveLight() const
{
	return getLight(active_light_index_);
}

const std::vector<std::shared_ptr<Light>> Scene::getLights() const
{
	return this->lights;
}

void Scene::applyFog(ShaderProgram& shader) const
{
	shader.setUniform("fog.fogType", fogType);
	shader.setUniform("fog.fogColor", fogColor);
	shader.setUniform("fog.density", fogDensity);
	shader.setUniform("fog.start", fogStart);
	shader.setUniform("fog.end", fogEnd);
}

int Scene::getShadingType() const
{
	return this->shadingModel;
}

void Scene::setShadingType(int type)
{
	this->shadingModel = type;
}

void Scene::setFogType(int type)
{
	this->fogType = type;
}

void Scene::setFogColor(const glm::vec4& color)
{
	this->fogColor = color;
}

void Scene::setFogBegin(float begin)
{
	this->fogStart = begin;
}

void Scene::setFogEnd(float end)
{
	this->fogEnd = end;
}

void Scene::setDensity(float den)
{
	this->fogDensity = den;
}

void Scene::setAmbientColor(const glm::vec4 & color)
{
	this->ambientColor = color;
}

const glm::vec4 & Scene::getAmbientColor() const
{
	return this->ambientColor;
}
