#define _USE_MATH_DEFINES

#include "Camera.h"
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

Camera::Camera(const glm::vec3& eye, const glm::vec3& at, const glm::vec3& up, const MeshModel& cameraModel) :
	MeshModel(cameraModel, "Camera"),
	view_transformation_(1.0f),
	worldViewTransformation(1.0f),
	projection_transformation_(1.0f),
	mat_inv(1.0f)
{
	this->znear = 0.1f;
	this->zfar = 200.0f;
	this->aspect = 16.0f / 9.0f;
	this->prm = 10;
	this->SetCameraLookAt(eye, at, up);
	this->SetOrthographicProjection(prm, aspect, znear, zfar);
}

Camera::~Camera()
{
}

float Camera::getZNear() const
{
	return znear;
}

float Camera::getZFar() const
{
	return zfar;
}

float Camera::getParam() const
{
	return this->prm;
}

float Camera::getAspect() const
{
	return aspect;
}

glm::mat4x4 Camera::getViewTransformation()
{
	return this->view_transformation_;
}

glm::mat4x4 Camera::getWorldViewTransformation()
{
	return this->worldViewTransformation;
}

glm::mat4x4 Camera::GetProjectionTransformation()
{
	return this->projection_transformation_;
}

void Camera::SetCameraLookAt(const glm::vec3& eye, const glm::vec3& at, const glm::vec3& up) {
	this->view_transformation_ = glm::lookAt(eye, at, up);
	this->mat_inv = glm::inverse(this->view_transformation_);
	setLocalTransformation(translationTransform);
	this->worldViewTransformation = glm::mat4(1.0f);
	this->worldTransform = glm::mat4(1.0f);
}

void Camera::SetOrthographicProjection(
	const float height,
	const float aspectRatio,
	const float zNear,
	const float zFar)
{
	float width = height * aspectRatio;
	this->zfar = zFar;
	this->znear = zNear;
	this->aspect = aspectRatio;
	this->prm = height;
	this->projection_transformation_ = glm::ortho(-width / 2, width / 2, -height / 2, height / 2, zNear, zFar);
	this->activeView = 0;
}

void Camera::SetPerspectiveProjection(
	const float fovy,
	const float aspectRatio,
	const float zNear,
	const float zFar)
{
	this->zfar = zFar;
	this->znear = zNear;
	this->aspect = aspectRatio;
	this->prm = fovy;
	this->prm = glm::min(fovy, glm::degrees(glm::pi<float>()));
	this->projection_transformation_ = glm::perspective(prm, aspectRatio, zNear, zFar);
	this->activeView = 1;
}

void Camera::SetZoom(const float zoom) {
	float val = this->prm * zoom;
	if (this->activeView == 0) {
		this->SetOrthographicProjection(val, this->aspect, this->znear, this->zfar);
	}
	else if (this->activeView == 1) {
		this->SetPerspectiveProjection(val, this->aspect, this->znear, this->zfar);
	}
}

void Camera::SetAspectRatio(const float ratio)
{
	this->aspect = ratio;
}



bool Camera::isPerspective() const
{
	return activeView;
}

void Camera::setObjectTransform(const glm::mat4 & mat)
{
	localTransform = mat_inv * translationTransform * xRotationTransform * yRotationTransform * zRotationTransform * scaleTransform;
	view_transformation_ = glm::inverse(localTransform);
}

void Camera::setWorldTransform(const glm::mat4 & mat)
{
	worldTransform = worldTranslationTransform * worldxRotationTransform * worldyRotationTransform * worldzRotationTransform * worldScaleTransform;
	worldViewTransformation = glm::inverse(worldTransform);
}
